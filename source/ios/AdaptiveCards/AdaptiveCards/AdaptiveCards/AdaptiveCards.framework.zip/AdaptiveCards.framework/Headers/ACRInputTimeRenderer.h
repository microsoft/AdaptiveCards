//
//  ACRInputTimeRenderer
//  ACRInputTimeRenderer.h
//
//  Copyright © 2017 Microsoft. All rights reserved.
//

#import "ACRBaseCardElementRenderer.h"

@interface ACRInputTimeRenderer:ACRBaseCardElementRenderer

+ (ACRInputTimeRenderer *)getInstance;

@end
