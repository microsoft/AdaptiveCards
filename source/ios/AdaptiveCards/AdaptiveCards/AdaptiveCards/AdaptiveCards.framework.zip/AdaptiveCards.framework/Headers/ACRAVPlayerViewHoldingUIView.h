//
//  ACRAVPlayerViewHoldingUIView
//  ACRAVPlayerViewHoldingUIView.h
//
//  Copyright © 2018 Microsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACRAVPlayerViewHoldingUIView:UIImageView

@property BOOL hidePlayIcon;

@end
