//
//  ACRBaseActionElementRenderer
//  ACRBaseActionElementRenderer.h
//
//  Copyright © 2017 Microsoft. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "ACRIBaseActionElementRenderer.h"

@interface ACRBaseActionElementRenderer:NSObject<ACRIBaseActionElementRenderer>

@end
