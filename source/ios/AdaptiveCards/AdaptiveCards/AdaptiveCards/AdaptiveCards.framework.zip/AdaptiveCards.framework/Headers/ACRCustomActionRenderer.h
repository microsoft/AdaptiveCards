//
//  ACRCustomActionRenderer
//  ACRCustomActionRenderer.h
//
//  Copyright © 2019 Microsoft. All rights reserved.
//

#import "ACRBaseActionElementRenderer.h"

@interface ACRCustomActionRenderer: ACRBaseActionElementRenderer

+ (ACRCustomActionRenderer* ) getInstance;

@end
