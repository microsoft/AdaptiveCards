//
//  ACOHostConfigParseResult.h
//  ACOHostConfigParseResult
//
//  Copyright © 2017 Microsoft. All rights reserved.
//

#import "ACOParseResult.h"

@class ACOHostConfig;

@interface ACOHostConfigParseResult:ACOParseResult

@property ACOHostConfig *config;

@end    
