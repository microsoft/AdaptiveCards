//
//  ACFramework.h
//  ACFramework
//
//  Copyright © 2017 Microsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ACFramework.
FOUNDATION_EXPORT double ADCIOSFrameworkVersionNumber;

//! Project version string for AFramework.
FOUNDATION_EXPORT const unsigned char ADCIOSFrameworkVersionString[];

#import <ADCIOSFramework/ACRViewController.h>

#import <ADCIOSFramework/ACRActionDelegate.h>


